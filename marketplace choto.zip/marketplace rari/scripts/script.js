function search() {
    let input = document.getElementById('searchbar').value;
    input=input.toLowerCase();
    let x = document.getElementsByClassName('cajadeproducto');
      
    for (i = 0; i < x.length; i++) { 
        if (!x[i].innerHTML.toLowerCase().includes(input)) {
            x[i].style.display="none";
            document.getElementById('nada').innerHTML = "Esos son todos nuestros resultados @_@!";
        }
        else {
            x[i].style.display="flex";   
            document.getElementById('nada').innerHTML = "";
              
        }
    }
}

let products = [];
let total = 0;

function add(product, price){
    console.log(product, price); 
    products.push(product);
    total = total + price;
    document.getElementById("checkout").innerHTML = `Pagar $${total}`;

    
}
function pay(){
    window.alert(products.join(", \n"));
    total = 0;
    products = [];
    document.getElementById("checkout").innerHTML = `Pagar $${total}`;
}

function darkMode() {
      
    const fecha = new Date(); 
    const hora = fecha.getHours();
   
    if(hora >= 0 && hora < 12){
        document.body.style.backgroundImage = "URL('img/background.jpg')";
        document.getElementById("all").style.backgroundColor = "rgb(231, 227, 179)";
        document.getElementById("nada").style.backgroundColor = "rgb(231, 227, 179)";
    }


        else if(hora >= 12 && hora < 24){
            document.body.style.backgroundImage = "URL('img/evilbackground.jpg')";
            
            document.getElementById("all").style.backgroundColor = "#3e1c45";

            // Cambiar color a cajadeproducto 
            var parent = document.getElementById("page-content");
            var child = parent.querySelectorAll(".cajadeproducto");
            for(let i=0; i < 10; i++) {
                child[i].style.backgroundColor = "#3e1c45";
            }
            // jaja evil marketplace
            document.getElementById("calvo").href = "dino.html";
            document.getElementById("calvo").innerHTML = "Evil Marketplace";


            // textito de los resultados adaptado al modo evil
            document.getElementById("nada").style.color = "black";
            document.getElementById("nada").style.backgroundColor = "#3e1c45";
    }

}


window.addEventListener("load",function() { darkMode() });


