const dino = document.getElementById("dino");
const cactus = document.getElementById("cactus");

function salto(){
    if(dispatchEvent.classList != "salto"){
        dino.classList.add("salto");
        setTimeout(function(){
            dino.classList.remove("salto");
        }, 300);
    }
}

let estaVivo = setInterval(function () {
    let dinoTop = parseInt(window.getComputedStyle(dino).getPropertyValue("top"));
    let hayCactus = parseInt(window.getComputedStyle(cactus).getPropertyValue("left"));
    if (hayCactus > 0 && hayCactus < 70 && dinoTop >= 143){
        dino.style.animationPlayState = "paused";
        cactus.style.animationPlayState = "paused";
        alert("sos re maloooo a casa");
        window.location.reload();
    }
}, 10);
document.addEventListener("keydown", function(event){ salto();});